let currentPlanIndex = null;
function parseTime(timeStr) {
  const parts = timeStr.split(':').map(Number);
  if (parts.length !== 2 || parts.some(isNaN)) return NaN;
  return parts[0] * 60 + parts[1];
}

function formatMinutes(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h} hr${h !== 1 ? 's' : ''} ${m} min${m !== 1 ? 's' : ''}`;
}

function savePlan(plan) {
  const plans = JSON.parse(localStorage.getItem('studyPlans')) || [];
  plans.push(plan);
  localStorage.setItem('studyPlans', JSON.stringify(plans));
  return plans.length - 1;
}

function deletePlan(index) {
  const plans = JSON.parse(localStorage.getItem('studyPlans')) || [];
  if (index < 0 || index >= plans.length) return;
  plans.splice(index, 1);
  localStorage.setItem('studyPlans', JSON.stringify(plans));
  alert('Study plan deleted!');
  document.getElementById('flowchartContainer').innerHTML = '';
  document.getElementById('previousPlansContainer').innerHTML = '';
}

function generateFlowchart(plan) {
  const { examName, examDate, studyTopics, subTopics, topicTime, subTopicTime } = plan;

  let html = `
  <div style="font-family: Arial, sans-serif; max-width: 700px; margin: 20px auto;">
    <h3 style="text-align: center;">Study Plan Flowchart for "${examName}" (Exam Date: ${examDate})</h3>
    <div style="display: flex; flex-direction: column; align-items: center;">`;

  studyTopics.forEach((topic, i) => {
    html += `
      <div style="background: #2c3e50; color: white; padding: 15px 25px; border-radius: 8px; font-weight: bold; min-width: 300px; text-align: center; position: relative;">
        ${topic}<br>
        <small style="font-weight: normal; font-size: 0.9em;">${formatMinutes(topicTime)}</small>
      </div>`;

    html += `
      <div style="width: 2px; height: 20px; background: #2c3e50; margin: 0 auto;"></div>`;

    html += `<div style="display: flex; gap: 15px; margin: 10px 0 30px;">`;

    subTopics.forEach((sub) => {
      html += `
        <div style="background: #85c1e9; color: #1b2838; padding: 10px 15px; border-radius: 6px; min-width: 120px; text-align: center; font-size: 0.9em; position: relative;">
          ${sub}<br>
          <small style="font-weight: normal;">${formatMinutes(subTopicTime)}</small>
          <div style="position: absolute; top: 100%; left: 50%; transform: translateX(-50%); width: 2px; height: 15px; background: #85c1e9;"></div>
        </div>`;
    });

    html += `</div>`;

    if (i !== studyTopics.length - 1) {
      html += `<div style="width: 2px; height: 30px; background: #2c3e50; margin: 0 auto;"></div>`;
    }
  });

  html += `</div></div>`;

  return html;
}




function showPreviousPlans() {
  const container = document.getElementById('previousPlansContainer');
  container.innerHTML = '<h2>Previous Study Plans</h2>';
  const plans = JSON.parse(localStorage.getItem('studyPlans')) || [];

  if (plans.length === 0) {
    container.innerHTML += '<p>No previous plans found.</p>';
    return;
  }

  plans.forEach((plan, idx) => {
    const planDiv = document.createElement('div');
    planDiv.classList.add('plan');
    planDiv.style.border = '1px solid #ccc';
    planDiv.style.padding = '10px';
    planDiv.style.marginBottom = '10px';
    planDiv.innerHTML = `
      <h3>${plan.examName} (Date: ${plan.examDate})</h3>
      <p><strong>Topics:</strong> ${plan.studyTopics.join(', ')}</p>
      <p><strong>Sub-topics:</strong> ${plan.subTopics.join(', ')}</p>
      <p><strong>Study Time per Topic:</strong> ${formatMinutes(plan.topicTime)}</p>
      <p><strong>Study Time per Sub-topic:</strong> ${formatMinutes(plan.subTopicTime)}</p>
      <button class="deleteBtn" data-index="${idx}" style="background:#e74c3c; color:#fff; border:none; padding:5px 10px; cursor:pointer; border-radius:4px;">Delete</button>
      ${generateFlowchart(plan)}
    `;
    container.appendChild(planDiv);
  });

  container.querySelectorAll('.deleteBtn').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = parseInt(e.target.getAttribute('data-index'));
      if (confirm('Are you sure you want to delete this plan?')) {
        deletePlan(idx);
        showPreviousPlans();
      }
    });
  });
}

document.getElementById('examForm').addEventListener('submit', e => {
  e.preventDefault();

  const examName = document.getElementById('examName').value.trim();
  const examDate = document.getElementById('examDate').value;
  const studyTopics = document.getElementById('studyTopics').value.split(',').map(t => t.trim()).filter(Boolean);
  const subTopics = document.getElementById('subTopics').value.split(',').map(t => t.trim()).filter(Boolean);
  const topicTimeStr = document.getElementById('topicTime').value.trim();
  const subTopicTimeStr = document.getElementById('subTopicTime').value.trim();

  if (!examName || !examDate || studyTopics.length === 0 || subTopics.length === 0) {
    alert('Please fill in all fields.');
    return;
  }

  const topicTime = parseTime(topicTimeStr);
  const subTopicTime = parseTime(subTopicTimeStr);

  if (isNaN(topicTime) || isNaN(subTopicTime)) {
    alert('Please enter valid time in Hours:Minutes format.');
    return;
  }

  const plan = {
    examName,
    examDate,
    studyTopics,
    subTopics,
    topicTime,
    subTopicTime,
  };

  currentPlanIndex = savePlan(plan);

  document.getElementById('flowchartContainer').innerHTML = generateFlowchart(plan);

  document.getElementById('DELETE').style.display = 'inline-block';

  document.getElementById('previousPlansContainer').innerHTML = '';

  e.target.reset();

  alert('Study plan added!');
});


document.getElementById('DELETE').addEventListener('click', () => {
    if (currentPlanIndex === null) {
      alert('No plan selected to delete.');
      return;
    }
    if (confirm('Are you sure you want to delete this study plan?')) {
      deletePlan(currentPlanIndex);
      currentPlanIndex = null;
      document.getElementById('flowchartContainer').innerHTML = '';
      document.getElementById('DELETE').style.display = 'none'; // hide delete button after deletion
    }
  });
  

document.getElementById('showPlansBtn').addEventListener('click', () => {
  showPreviousPlans();
  document.getElementById('DELETE').style.display = 'none';
  currentPlanIndex = null;
});
